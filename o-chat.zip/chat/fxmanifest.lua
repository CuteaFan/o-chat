fx_version "adamant"
game "gta5"
Author 'Subils#9937'
modifier '! ! Oscar16#6272'

server_scripts { "modules/server/*.lua" }

client_scripts { "modules/client/*.lua" }

ui_page { "nui/index.html" }

files { "**/**/**/**/**/**/**/**/**/**/**/**/*.*" }