Config        = {}
Config.Locale = 'en'

Config.EnableESXIdentity = false 
Config.OnlyFirstname     = false